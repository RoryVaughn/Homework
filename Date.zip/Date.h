#ifndef DATE_H
#define DATE_H

/*
Create a class called Date.
The class should contain variables and functions to store and retrieve a date
in the form DD/MM/YYYY
*/

/*
Create a date object
Parameters: d, m , y
where d is the day
m is the month
y is the year
PostCondition: a Date object that will contain the day month
and year specifried by user
Usage: Date <variable name>(31, 08, 2015);
*/

class Date
{
	public:
		Date(int, int, int);
		void PrintDate();

	private:
		int day;
		int month;
		int year;
};

#endif
